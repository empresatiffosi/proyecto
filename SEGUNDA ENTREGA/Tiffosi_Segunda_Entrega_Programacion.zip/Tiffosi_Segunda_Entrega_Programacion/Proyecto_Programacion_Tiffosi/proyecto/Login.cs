﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIGEN
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            btnAceptar.FlatStyle = FlatStyle.Flat; // Establece el estilo plano
            btnAceptar.TextAlign = ContentAlignment.MiddleCenter; // Centra el texto
            btnAceptar.FlatAppearance.BorderSize = 1; // Elimina el borde
            btnAceptar.FlatAppearance.BorderColor = Color.Black;

            btnMostrar.FlatStyle = FlatStyle.Flat; // Establece el estilo plano
            btnMostrar.TextAlign = ContentAlignment.MiddleCenter; // Centra el texto
            btnMostrar.FlatAppearance.BorderSize = 2; // Elimina el borde
            btnMostrar.FlatAppearance.BorderColor = Color.Black;

        }
        private void btnAceptar_GotFocus(object sender, EventArgs e)
        {
        }
        public void SetCredentials(string username, string password)
        {
            txtUsuario.Text = username;
            txtContrasenia.Text = password;
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            try
            {
                // Primero la dirección de conexión
                Program.cn.Open("miodbc", txtUsuario.Text, txtContrasenia.Text);
            }
            catch
            {
                MessageBox.Show("Usuario o Contraseña Incorrectos");
                return;
            }

            // Configurar propiedades de la conexión
            Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;

            // Dar permisos basados en el usuario
            Program.Doypermisos(txtUsuario.Text);

            Program.frmPrincipal.WindowState = FormWindowState.Normal;
            Program.frmLogin.Close();


        }


        private void txtUsuario_TextChanged(object sender, EventArgs e)
        {
         
        }

        private void txtContrasenia_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) /*BOTON MUESTRA CONTRASEÑA*/
        {
            if (txtContrasenia.PasswordChar == '*')
            {
                // Si la contraseña está oculta, la mostramos
                txtContrasenia.PasswordChar = '\0'; // '\0' indica que no hay ningún carácter para ocultar
            }
            else
            {
                // Si la contraseña está visible, la ocultamos
                txtContrasenia.PasswordChar = '*';
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
         
            
       
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SIGEN
{
    public partial class Clientes : Form
    {

        public Clientes()


        {
            InitializeComponent();



        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Clientes_Load(object sender, EventArgs e)
        {
            gbDatos.Visible = false;

            btnBuscar.FlatStyle = FlatStyle.Flat; // Establece el estilo plano
            btnBuscar.TextAlign = ContentAlignment.MiddleCenter; // Centra el texto
            btnBuscar.FlatAppearance.BorderSize = 2; // Elimina el borde
            btnBuscar.FlatAppearance.BorderColor = Color.Black;

            btnGuardar.FlatStyle = FlatStyle.Flat; // Establece el estilo plano
            btnGuardar.TextAlign = ContentAlignment.MiddleCenter; // Centra el texto
            btnGuardar.FlatAppearance.BorderSize = 2; // Elimina el borde
            btnGuardar.FlatAppearance.BorderColor = Color.Black;


        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {

            Cliente c;
            int documento;
            if (!Int32.TryParse(txtCi.Text, out documento))
            {
                MessageBox.Show("la cedula de indentidad debe ser numerica");
            }
            else
            {
                c = new Cliente();
                c.Ci = documento;
                c.Conexion = Program.cn;
                switch (c.Buscar())
                {
                    case 0: //Encontre - Modificaciòn
                        gbBuscar.Enabled = false;
                        gbDatos.Visible = true;
                        btnEliminar.Enabled = true;
                        txtNombre.Text = c.Nombre;
                        cboTelefonos.Items.Clear();
                        btnGuardar.Text = "Modificar";

                        foreach (string telefono in c.Telefonos)
                        {
                            cboTelefonos.Items.Add(telefono);
                        }
                        cboTelefonos.SelectedIndex = 0; //MOSTRAR PRIMER NÙMERO SELECCIONADO
                        break;


                    case 1: MessageBox.Show("ha perdido la sesión. Debe loguearse nuevamente"); break;
                    case 2:
                    case 3: //no se encontró

                        DialogResult resultado = MessageBox.Show("¿desea agregar el usuario?" /*DAR DE ALTA*/, "¿Agregar?", MessageBoxButtons.YesNo);

                        if (resultado == DialogResult.Yes)
                        {
                            gbBuscar.Enabled = false;
                            gbDatos.Visible = true;
                            btnEliminar.Enabled = false;
                            txtNombre.Clear();
                            cboTelefonos.Items.Clear();
                            gbDatos.Visible = Enabled;
                            btnGuardar.Text = "Guardar";
                            cboTelefonos.Text = "";
                        }
                        /*PROPIEDAD ACCEPT BUTTON EN EL FORMULARIO PARA PODER DARLE ENTER*/
                        break;
                    case 4: MessageBox.Show("hubo errores al buscar. en caso de repetirse, avisar al administrador"); break;


                }
                c = null;

            }

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            Int32 cedula;
            Cliente c;
            if (!Int32.TryParse(txtCi.Text, out cedula))
            {
                MessageBox.Show("la cedula de indentidad debe ser numerica");

            }
            else
            {
                c = new Cliente();
                c.Conexion = Program.cn;
                c.Ci = cedula;
                switch (c.Eliminar())
                {
                    case 0:
                        DialogResult resultado = MessageBox.Show("¿desea eliminar el usuario?" /*DAR DE BAJA*/, "¿Borrar?", MessageBoxButtons.YesNo);

                        if (resultado == DialogResult.Yes)
                        {
                            gbBuscar.Enabled = true;
                            gbDatos.Visible = false;
                            txtCi.Clear();
                        }
                        break;
                    case 1:
                        MessageBox.Show("ha perdido la sessión debe loguearse nuevamente");
                        break;
                    case 2:
                        MessageBox.Show("Error 2");
                        break;
                    case 3:
                        MessageBox.Show("Error 3");
                        break;

                }//switch
                c = null; //libero memoria
            }//if
        }//btnEliminar


        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Int32 cedula = 0; Cliente c;
            if (!Int32.TryParse(txtCi.Text, out cedula))
            {
                MessageBox.Show("CI debe ser numerica");
            }
            else
            {
                c = new Cliente();
                c.Ci = cedula;
                c.Nombre = txtNombre.Text;
                c.Conexion = Program.cn;
                foreach (string telefono in cboTelefonos.Items)
                {
                    c.Telefonos.Add(telefono);

                }
                switch (c.Guardar(btnEliminar.Enabled))
                {
                    case 0:
                        gbBuscar.Enabled = true;
                        gbDatos.Visible = false;
                        txtCi.Text = "";

                        break;
                    case 1:
                        MessageBox.Show("perdio la sesiòn. Debe loguearse nuevamente");

                        break;
                    case 2: MessageBox.Show("Error 2"); break;
                    case 3: MessageBox.Show("Error 3"); break;// error borrar telefonos 
                    case 4: MessageBox.Show("Error 4"); break;// error al insertar telefonos 
                }//switch
                c = null;
            } // if
        }//btn guardar

        private void btnAgregar_Click(object sender, EventArgs e)
        {
     
                if (cboTelefonos.Items.IndexOf(cboTelefonos.Text) < 0)
                {
                    cboTelefonos.Items.Add(cboTelefonos.Text);
                }
                else
                {
                    MessageBox.Show("El telefono ya existe en la lista");
                }
            }

        private void btnQuitar_Click(object sender, EventArgs e) //QUITAR TELÉFONO
        {
            if (cboTelefonos.Items.IndexOf(cboTelefonos.Text) < 0)
            {
                MessageBox.Show("El Teléfono no existe en la lista.");
                cboTelefonos.Text = "";
            }
            else
            {
                cboTelefonos.Items.Remove(cboTelefonos.Text);
                cboTelefonos.Text = string.Empty;

            }


        }

        private void button7_Click(object sender, EventArgs e) //BOTON CANCELAR
        {
            this.Close();
        }
    }
      }
  





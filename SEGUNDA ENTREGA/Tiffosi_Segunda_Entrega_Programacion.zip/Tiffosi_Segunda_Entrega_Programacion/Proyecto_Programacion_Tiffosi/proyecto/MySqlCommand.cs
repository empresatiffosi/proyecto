﻿namespace SIGEN
{
    internal class MySqlCommand
    {
        private string sqlSelect;
        private MySqlConnection conn;

        public MySqlCommand(string sqlSelect, MySqlConnection conn)
        {
            this.sqlSelect = sqlSelect;
            this.conn = conn;
        }
    }
}
﻿using SIGEN;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIGEN
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();            
        }

        private void Principal_Load(object sender, EventArgs e)
        {
            this.menuEntrenadores.Visible = false;
            this.menuPerfil.Visible = false;
            this.menuCerrarSesion.Visible = false;
            this.menuAdministracion.Visible = false;


        
        }

        private void aplicaionesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }



        private void menuClientes_Click(object sender, EventArgs e)
        {
            Program.frmClientes = new Clientes();
            Program.frmClientes.MdiParent = this;
            Program.frmClientes.Show();
            this.LayoutMdi(MdiLayout.TileHorizontal);
            this.LayoutMdi(MdiLayout.TileVertical);
        }
        



        private void menuSalir_Click(object sender, EventArgs e)
        {
           Program.frmPrincipal.Close();

        }

        private void menuEntrenador_Click(object sender, EventArgs e)
        {
            Program.frmEntrenador = new Entrenador();
            Program.frmEntrenador.MdiParent = this;
            Program.frmEntrenador.Show();
            this.LayoutMdi(MdiLayout.TileHorizontal);
            this.LayoutMdi(MdiLayout.TileVertical);
        }

        private void menuAplicacion_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void menuInformacion_Click(object sender, EventArgs e)
        {
            Program.frmUsuarios = new Usuarios();
            Program.frmUsuarios.MdiParent = this;
            Program.frmUsuarios.Show();

            this.LayoutMdi(MdiLayout.TileHorizontal);
            this.LayoutMdi(MdiLayout.TileVertical);
            if (Program.cn.State != 0)
            {
                Program.frmUsuarios.txtID.Visible = true;
                Program.frmUsuarios.ID_USU.Visible = true;
            }
        }

        private void rutinaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program.frmRutina = new Rutina();
            Program.frmRutina.MdiParent = this;
            Program.frmRutina.Show();
            this.LayoutMdi(MdiLayout.TileHorizontal);
            this.LayoutMdi(MdiLayout.TileVertical);
        }

        private void menuPerfil_Click(object sender, EventArgs e)
        {

        }

        private void menuLogin_Click(object sender, EventArgs e)
        {
            Program.frmLogin = new Login();
            Program.frmLogin.MdiParent = this;
            Program.frmLogin.Show();
            this.LayoutMdi(MdiLayout.TileHorizontal);
            this.LayoutMdi(MdiLayout.TileVertical);

        
        }

        private void menuCerrarSesion_Click(object sender, EventArgs e)
        {
            DialogResult respuesta = MessageBox.Show("¿Desea cerrar sesión?", "Logout", MessageBoxButtons.YesNo);
            if (respuesta == DialogResult.Yes)
            {
                // CERRAR LA CONEXIÓN u otros procesos necesarios al cerrar sesión
                Program.cn.Close();
                
                this.menuEntrenadores.Visible = false;
                this.menuPerfil.Visible = false;
                this.menuCerrarSesion.Visible = false;
                this.menuLogin.Visible = true;
                this.menuRegistrarse.Visible = true;
                this.menuAdministracion.Visible = false;

            }

            this.LayoutMdi(MdiLayout.TileHorizontal); //AJUSTAR VENTANA HORIZONTALMENTE
            this.LayoutMdi(MdiLayout.TileVertical); //AJUSTAR VENTANA VERTICALMENTE
        }
        private void menuRegistrarse_Click(object sender, EventArgs e)
        {
            Program.frmUsuarios = new Usuarios();
            Program.frmUsuarios.MdiParent = this;
            Program.frmUsuarios.Show();
            this.LayoutMdi(MdiLayout.TileHorizontal);
            this.LayoutMdi(MdiLayout.TileVertical);

        }

        private void menuGestion_Click(object sender, EventArgs e)
        {

        }

        private void altaDeUsuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program.frmGestionUsuarios = new GestionUsuarios();
            Program.frmGestionUsuarios.MdiParent = this;
            Program.frmGestionUsuarios.Show();

            this.LayoutMdi(MdiLayout.TileHorizontal);
            this.LayoutMdi(MdiLayout.TileVertical);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}

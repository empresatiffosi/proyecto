﻿
namespace SIGEN
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuAplicacion = new System.Windows.Forms.MenuStrip();
            this.menuEntrenadores = new System.Windows.Forms.ToolStripMenuItem();
            this.menuClientes = new System.Windows.Forms.ToolStripMenuItem();
            this.menuEntrenador = new System.Windows.Forms.ToolStripMenuItem();
            this.menuAdministracion = new System.Windows.Forms.ToolStripMenuItem();
            this.altaDeUsuarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRegistrarse = new System.Windows.Forms.ToolStripMenuItem();
            this.menuPerfil = new System.Windows.Forms.ToolStripMenuItem();
            this.menuInformacion = new System.Windows.Forms.ToolStripMenuItem();
            this.rutinaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuLogin = new System.Windows.Forms.ToolStripMenuItem();
            this.menuCerrarSesion = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSalir = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuAplicacion.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // menuAplicacion
            // 
            this.menuAplicacion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(52)))), ((int)(((byte)(45)))));
            this.menuAplicacion.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuEntrenadores,
            this.menuAdministracion,
            this.menuRegistrarse,
            this.menuPerfil,
            this.menuLogin,
            this.menuCerrarSesion,
            this.menuSalir});
            this.menuAplicacion.Location = new System.Drawing.Point(0, 0);
            this.menuAplicacion.Name = "menuAplicacion";
            this.menuAplicacion.Size = new System.Drawing.Size(830, 24);
            this.menuAplicacion.TabIndex = 1;
            this.menuAplicacion.Text = "menuStrip1";
            this.menuAplicacion.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuAplicacion_ItemClicked);
            // 
            // menuEntrenadores
            // 
            this.menuEntrenadores.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuClientes,
            this.menuEntrenador});
            this.menuEntrenadores.Name = "menuEntrenadores";
            this.menuEntrenadores.Size = new System.Drawing.Size(88, 20);
            this.menuEntrenadores.Text = "Entrenadores";
            this.menuEntrenadores.Click += new System.EventHandler(this.aplicaionesToolStripMenuItem_Click);
            // 
            // menuClientes
            // 
            this.menuClientes.Name = "menuClientes";
            this.menuClientes.Size = new System.Drawing.Size(180, 22);
            this.menuClientes.Text = "Clientes";
            this.menuClientes.Click += new System.EventHandler(this.menuClientes_Click);
            // 
            // menuEntrenador
            // 
            this.menuEntrenador.Name = "menuEntrenador";
            this.menuEntrenador.Size = new System.Drawing.Size(180, 22);
            this.menuEntrenador.Text = "Entrenador";
            this.menuEntrenador.Click += new System.EventHandler(this.menuEntrenador_Click);
            // 
            // menuAdministracion
            // 
            this.menuAdministracion.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.altaDeUsuarioToolStripMenuItem});
            this.menuAdministracion.Name = "menuAdministracion";
            this.menuAdministracion.Size = new System.Drawing.Size(100, 20);
            this.menuAdministracion.Text = "Administración";
            this.menuAdministracion.Click += new System.EventHandler(this.menuGestion_Click);
            // 
            // altaDeUsuarioToolStripMenuItem
            // 
            this.altaDeUsuarioToolStripMenuItem.Name = "altaDeUsuarioToolStripMenuItem";
            this.altaDeUsuarioToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.altaDeUsuarioToolStripMenuItem.Text = "Gestión de Usuarios";
            this.altaDeUsuarioToolStripMenuItem.Click += new System.EventHandler(this.altaDeUsuarioToolStripMenuItem_Click);
            // 
            // menuRegistrarse
            // 
            this.menuRegistrarse.Name = "menuRegistrarse";
            this.menuRegistrarse.Size = new System.Drawing.Size(76, 20);
            this.menuRegistrarse.Text = "Registrarse";
            this.menuRegistrarse.Click += new System.EventHandler(this.menuRegistrarse_Click);
            // 
            // menuPerfil
            // 
            this.menuPerfil.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuInformacion,
            this.rutinaToolStripMenuItem});
            this.menuPerfil.Name = "menuPerfil";
            this.menuPerfil.Size = new System.Drawing.Size(46, 20);
            this.menuPerfil.Text = "Perfil";
            this.menuPerfil.Click += new System.EventHandler(this.menuPerfil_Click);
            // 
            // menuInformacion
            // 
            this.menuInformacion.Name = "menuInformacion";
            this.menuInformacion.Size = new System.Drawing.Size(180, 22);
            this.menuInformacion.Text = "Información";
            this.menuInformacion.Click += new System.EventHandler(this.menuInformacion_Click);
            // 
            // rutinaToolStripMenuItem
            // 
            this.rutinaToolStripMenuItem.Name = "rutinaToolStripMenuItem";
            this.rutinaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.rutinaToolStripMenuItem.Text = "Rutina";
            this.rutinaToolStripMenuItem.Click += new System.EventHandler(this.rutinaToolStripMenuItem_Click);
            // 
            // menuLogin
            // 
            this.menuLogin.Name = "menuLogin";
            this.menuLogin.Size = new System.Drawing.Size(88, 20);
            this.menuLogin.Text = "Iniciar Sesión";
            this.menuLogin.Click += new System.EventHandler(this.menuLogin_Click);
            // 
            // menuCerrarSesion
            // 
            this.menuCerrarSesion.Name = "menuCerrarSesion";
            this.menuCerrarSesion.Size = new System.Drawing.Size(88, 20);
            this.menuCerrarSesion.Text = "Cerrar Sesion";
            this.menuCerrarSesion.Click += new System.EventHandler(this.menuCerrarSesion_Click);
            // 
            // menuSalir
            // 
            this.menuSalir.Name = "menuSalir";
            this.menuSalir.Size = new System.Drawing.Size(41, 20);
            this.menuSalir.Text = "Salir";
            this.menuSalir.Click += new System.EventHandler(this.menuSalir_Click);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(61, 4);
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(830, 602);
            this.Controls.Add(this.menuAplicacion);
            this.ForeColor = System.Drawing.SystemColors.MenuText;
            this.IsMdiContainer = true;
            this.Name = "Principal";
            this.Text = "SIGEN";
            this.Load += new System.EventHandler(this.Principal_Load);
            this.menuAplicacion.ResumeLayout(false);
            this.menuAplicacion.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.MenuStrip menuAplicacion;
        public System.Windows.Forms.ToolStripMenuItem menuEntrenadores;
        public System.Windows.Forms.ToolStripMenuItem menuClientes;
        public System.Windows.Forms.ToolStripMenuItem menuEntrenador;
        private System.Windows.Forms.ToolStripMenuItem menuSalir;
        private System.Windows.Forms.ToolStripMenuItem menuInformacion;
        private System.Windows.Forms.ToolStripMenuItem rutinaToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem menuPerfil;
        public System.Windows.Forms.ToolStripMenuItem menuLogin;
        public System.Windows.Forms.ToolStripMenuItem menuCerrarSesion;
        public System.Windows.Forms.ToolStripMenuItem menuRegistrarse;
        private System.Windows.Forms.ToolStripMenuItem altaDeUsuarioToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem menuAdministracion;
    }
}
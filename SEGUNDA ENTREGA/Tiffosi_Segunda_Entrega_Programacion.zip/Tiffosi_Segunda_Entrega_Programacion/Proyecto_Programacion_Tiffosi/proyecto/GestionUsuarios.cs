﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; // Para SQL Server


namespace SIGEN
{
    public partial class GestionUsuarios : Form
    {
        private object dgvDatos;

        public GestionUsuarios()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e) // AGREGAR USUARIO
        {
            string usuario = textBox2.Text;
            string contrasena = textBox3.Text;
            string sql;
            object filasAfectadas;

            try
            {
                // Crear el usuario
                sql = $"CREATE USER {usuario} IDENTIFIED BY '{contrasena}';";
                Program.cn.Execute(sql, out filasAfectadas);

                // Conceder permisos
                sql = $"GRANT SELECT ON usuario_rol TO {usuario};";
                Program.cn.Execute(sql, out filasAfectadas);

                sql = $"GRANT SELECT ON roles TO {usuario};";
                Program.cn.Execute(sql, out filasAfectadas);

                // Insertar en usuario_rol
                sql = $"INSERT INTO usuario_rol(usuario, rol) VALUES('{usuario}', 1);";
                Program.cn.Execute(sql, out filasAfectadas);

                MessageBox.Show("Usuario creado con éxito.");


                Program.frmPrincipal.Hide(); // Opcional: Ocultar el formulario actual

                Program.frmUsuarios = new Usuarios();
                Program.frmUsuarios.Show();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            };
            }
        
        

        private void button4_Click(object sender, EventArgs e) // ELIMINAR USUARIO
        {
            string usuario = textBox2.Text;

            string sql;
            object filasAfectadas;

            if (string.IsNullOrWhiteSpace(usuario))
            {
                MessageBox.Show("Por favor, ingrese un nombre de usuario.");
                return;
            }

            try
            {

                // Revocar permisos del usuario antes de eliminarlo
                sql = $"REVOKE ALL PRIVILEGES ON usuario_rol FROM {usuario};";
                Program.cn.Execute(sql, out filasAfectadas);

                sql = $"REVOKE ALL PRIVILEGES ON roles FROM {usuario};";
                Program.cn.Execute(sql, out filasAfectadas);

                // Eliminar el usuario
                sql = $"DROP USER {usuario};";
                Program.cn.Execute(sql, out filasAfectadas);

                sql = $"delete from usuario_rol WHERE Usuario='{usuario}';";
                Program.cn.Execute(sql, out filasAfectadas);

                MessageBox.Show("Usuario Eliminado");
                textBox2.Clear();
                textBox3.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            
    }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql;
            object filasAfectadas;

            string nombreBuscado = Program.frmGestionUsuarios.textBox1.Text; // Suponiendo que tu TextBox se llama textBox1

            if (nombreBuscado == "Gustavo")
            {
                try
                {
                    Program.frmGestionUsuarios.dataGridView1.ColumnCount = 6;
                    Program.frmGestionUsuarios.dataGridView1.Columns[0].Name = "Nombre";
                    Program.frmGestionUsuarios.dataGridView1.Columns[1].Name = "Apellido";
                    Program.frmGestionUsuarios.dataGridView1.Columns[2].Name = "Ci";
                    Program.frmGestionUsuarios.dataGridView1.Columns[3].Name = "fecha de nacimiento";
                    Program.frmGestionUsuarios.dataGridView1.Columns[4].Name = "departamento";
                    Program.frmGestionUsuarios.dataGridView1.Columns[5].Name = "telefono";

                    Program.frmGestionUsuarios.dataGridView1.Rows.Add("Gustavo", "Cassanello", "55814646", "01/01/2024", "Montevideo", "093336020");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al agregar usuario: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Error al buscar usuario", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void GestionUsuarios_Load(object sender, EventArgs e)
        {
            button2.FlatStyle = FlatStyle.Flat; // Establece el estilo plano
            button2.TextAlign = ContentAlignment.MiddleCenter; // Centra el texto
            button2.FlatAppearance.BorderSize = 2; // Elimina el borde
            button2.FlatAppearance.BorderColor = Color.Black;

            button1.FlatStyle = FlatStyle.Flat; // Establece el estilo plano
            button1.TextAlign = ContentAlignment.MiddleCenter; // Centra el texto
            button1.FlatAppearance.BorderSize = 2; // Elimina el borde
            button1.FlatAppearance.BorderColor = Color.Black;


            button4.FlatStyle = FlatStyle.Flat; // Establece el estilo plano
            button4.TextAlign = ContentAlignment.MiddleCenter; // Centra el texto
            button4.FlatAppearance.BorderSize = 2; // Elimina el borde
            button4.FlatAppearance.BorderColor = Color.Black;
            button4.BackColor = Color.White; // Establece el fondo blanco

            label1.Font = new Font(label1.Font, label1.Font.Style | FontStyle.Underline);
            label2.Font = new Font(label1.Font, label1.Font.Style | FontStyle.Underline);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        



    }
}

﻿namespace SIGEN
{
    internal class MySqlDataAdapter
    {
    }
}
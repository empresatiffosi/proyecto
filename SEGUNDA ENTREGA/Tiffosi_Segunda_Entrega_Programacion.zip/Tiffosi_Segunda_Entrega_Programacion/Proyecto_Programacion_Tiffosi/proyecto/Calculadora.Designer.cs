﻿
namespace Calculadora
{
    partial class Calculadora
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.btnSuma = new System.Windows.Forms.Button();
            this.btnResta = new System.Windows.Forms.Button();
            this.btnMultiplicacion = new System.Windows.Forms.Button();
            this.btnDivision = new System.Windows.Forms.Button();
            this.btnRestart = new System.Windows.Forms.Button();
            this.lstResultado = new System.Windows.Forms.ListBox();
            this.cboResultado = new System.Windows.Forms.ComboBox();
            this.chkResultado = new System.Windows.Forms.CheckBox();
            this.chkFondo = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // txtNum1
            // 
            this.txtNum1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtNum1.CausesValidation = false;
            this.txtNum1.ForeColor = System.Drawing.Color.Black;
            this.txtNum1.Location = new System.Drawing.Point(29, 52);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(231, 20);
            this.txtNum1.TabIndex = 0;
            this.txtNum1.TabStop = false;
            this.txtNum1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNum2
            // 
            this.txtNum2.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtNum2.ForeColor = System.Drawing.Color.Black;
            this.txtNum2.Location = new System.Drawing.Point(319, 52);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(231, 20);
            this.txtNum2.TabIndex = 1;
            this.txtNum2.TabStop = false;
            this.txtNum2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblResultado
            // 
            this.lblResultado.BackColor = System.Drawing.Color.White;
            this.lblResultado.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblResultado.Font = new System.Drawing.Font("Noto Serif Cond", 12F);
            this.lblResultado.ForeColor = System.Drawing.Color.RosyBrown;
            this.lblResultado.Location = new System.Drawing.Point(615, 52);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(100, 23);
            this.lblResultado.TabIndex = 2;
            this.lblResultado.Tag = "lbl Resultado";
            // 
            // btnSuma
            // 
            this.btnSuma.BackColor = System.Drawing.Color.White;
            this.btnSuma.Font = new System.Drawing.Font("Noto Serif Cond", 14.25F);
            this.btnSuma.ForeColor = System.Drawing.Color.RosyBrown;
            this.btnSuma.Location = new System.Drawing.Point(365, 141);
            this.btnSuma.Name = "btnSuma";
            this.btnSuma.Size = new System.Drawing.Size(140, 32);
            this.btnSuma.TabIndex = 3;
            this.btnSuma.Tag = "btnSuma";
            this.btnSuma.Text = "Botón Suma";
            this.btnSuma.UseVisualStyleBackColor = false;
            this.btnSuma.Click += new System.EventHandler(this.btnSuma_Click);
            // 
            // btnResta
            // 
            this.btnResta.BackColor = System.Drawing.Color.White;
            this.btnResta.Font = new System.Drawing.Font("Noto Serif Cond", 14.25F);
            this.btnResta.ForeColor = System.Drawing.Color.RosyBrown;
            this.btnResta.Location = new System.Drawing.Point(543, 141);
            this.btnResta.Name = "btnResta";
            this.btnResta.Size = new System.Drawing.Size(140, 32);
            this.btnResta.TabIndex = 4;
            this.btnResta.Tag = "btnResta";
            this.btnResta.Text = "Botón Resta";
            this.btnResta.UseVisualStyleBackColor = false;
            this.btnResta.Click += new System.EventHandler(this.btnResta_Click);
            // 
            // btnMultiplicacion
            // 
            this.btnMultiplicacion.BackColor = System.Drawing.Color.White;
            this.btnMultiplicacion.Font = new System.Drawing.Font("Noto Serif Cond", 14.25F);
            this.btnMultiplicacion.ForeColor = System.Drawing.Color.RosyBrown;
            this.btnMultiplicacion.Location = new System.Drawing.Point(365, 213);
            this.btnMultiplicacion.Name = "btnMultiplicacion";
            this.btnMultiplicacion.Size = new System.Drawing.Size(140, 32);
            this.btnMultiplicacion.TabIndex = 5;
            this.btnMultiplicacion.Tag = "btnMultiplicacion";
            this.btnMultiplicacion.Text = "Botón Multi";
            this.btnMultiplicacion.UseVisualStyleBackColor = false;
            this.btnMultiplicacion.Click += new System.EventHandler(this.btnMultiplicacion_Click);
            // 
            // btnDivision
            // 
            this.btnDivision.BackColor = System.Drawing.Color.White;
            this.btnDivision.Font = new System.Drawing.Font("Noto Serif Cond", 14.25F);
            this.btnDivision.ForeColor = System.Drawing.Color.RosyBrown;
            this.btnDivision.Location = new System.Drawing.Point(543, 213);
            this.btnDivision.Name = "btnDivision";
            this.btnDivision.Size = new System.Drawing.Size(140, 32);
            this.btnDivision.TabIndex = 6;
            this.btnDivision.Tag = "btnDivision";
            this.btnDivision.Text = "Botón División";
            this.btnDivision.UseVisualStyleBackColor = false;
            this.btnDivision.Click += new System.EventHandler(this.btnDivision_Click);
            // 
            // btnRestart
            // 
            this.btnRestart.BackColor = System.Drawing.Color.White;
            this.btnRestart.Font = new System.Drawing.Font("Noto Serif Cond", 14.25F);
            this.btnRestart.ForeColor = System.Drawing.Color.RosyBrown;
            this.btnRestart.Location = new System.Drawing.Point(477, 277);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(100, 35);
            this.btnRestart.TabIndex = 7;
            this.btnRestart.Text = "Reiniciar";
            this.btnRestart.UseVisualStyleBackColor = false;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // lstResultado
            // 
            this.lstResultado.FormattingEnabled = true;
            this.lstResultado.Location = new System.Drawing.Point(29, 111);
            this.lstResultado.Name = "lstResultado";
            this.lstResultado.Size = new System.Drawing.Size(120, 108);
            this.lstResultado.TabIndex = 8;
            this.lstResultado.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // cboResultado
            // 
            this.cboResultado.FormattingEnabled = true;
            this.cboResultado.Location = new System.Drawing.Point(29, 248);
            this.cboResultado.Name = "cboResultado";
            this.cboResultado.Size = new System.Drawing.Size(115, 21);
            this.cboResultado.TabIndex = 9;
            this.cboResultado.SelectedIndexChanged += new System.EventHandler(this.cboResultado_SelectedIndexChanged);
            // 
            // chkResultado
            // 
            this.chkResultado.AutoSize = true;
            this.chkResultado.Checked = true;
            this.chkResultado.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkResultado.ForeColor = System.Drawing.Color.Black;
            this.chkResultado.Location = new System.Drawing.Point(29, 295);
            this.chkResultado.Name = "chkResultado";
            this.chkResultado.Size = new System.Drawing.Size(107, 17);
            this.chkResultado.TabIndex = 10;
            this.chkResultado.Text = "Mostrar resultado";
            this.chkResultado.UseVisualStyleBackColor = true;
            this.chkResultado.CheckedChanged += new System.EventHandler(this.chkResultado_CheckedChanged);
            // 
            // chkFondo
            // 
            this.chkFondo.AutoSize = true;
            this.chkFondo.ForeColor = System.Drawing.Color.Black;
            this.chkFondo.Location = new System.Drawing.Point(29, 322);
            this.chkFondo.Name = "chkFondo";
            this.chkFondo.Size = new System.Drawing.Size(93, 17);
            this.chkFondo.TabIndex = 11;
            this.chkFondo.Text = "Fondo celeste";
            this.chkFondo.UseVisualStyleBackColor = true;
            this.chkFondo.CheckedChanged += new System.EventHandler(this.chkFondo_CheckedChanged);
            // 
            // Calculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(741, 507);
            this.Controls.Add(this.chkFondo);
            this.Controls.Add(this.chkResultado);
            this.Controls.Add(this.cboResultado);
            this.Controls.Add(this.lstResultado);
            this.Controls.Add(this.btnRestart);
            this.Controls.Add(this.btnDivision);
            this.Controls.Add(this.btnMultiplicacion);
            this.Controls.Add(this.btnResta);
            this.Controls.Add(this.btnSuma);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.ForeColor = System.Drawing.Color.Red;
            this.Name = "Calculadora";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Button btnSuma;
        private System.Windows.Forms.Button btnResta;
        private System.Windows.Forms.Button btnMultiplicacion;
        private System.Windows.Forms.Button btnDivision;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.ListBox lstResultado;
        private System.Windows.Forms.ComboBox cboResultado;
        private System.Windows.Forms.CheckBox chkResultado;
        private System.Windows.Forms.CheckBox chkFondo;
    }
}


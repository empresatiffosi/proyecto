﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIGEN
{
    class Cliente

    {

        protected int _ci;
        protected string _nombre;
        protected List<string> _telefonos;
        protected ADODB.Connection _conexion;



        public Cliente()
        {

            _ci = 0;
            _nombre = "";
            _telefonos = new List<string>();
            _conexion = new ADODB.Connection();

        }
        public Cliente(int c, string n, List<string> t, ADODB.Connection cn)
        {
            _ci = c;
            _nombre = n;
            _telefonos = t;
            _conexion = cn;

        }

        public int Ci
        {
            set { _ci = value; }
            get { return (_ci); }
        }
        public string Nombre
        {
            set { _nombre = value; }
            get { return (_nombre); }
        }
        public List<string> Telefonos
        {
            set { _telefonos = value; }
            get { return (_telefonos); }
        }
        public ADODB.Connection Conexion
        {
            set { _conexion = value; }
            get { return (_conexion); }
        }
        internal class UsuPass
        {
            public String Usuario { set; get; }
            public String Contrasenia { set; get; }

        }

        public byte Buscar()
        {
            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;
            byte resultado = 0;// POR DEFECTO ASUME QUE LO ENCONTRE
            if (_conexion.State == 0)
            {
                resultado = 1; //CONEXION CERRADA

            }
            else
            {
                sql = "select nombre from clientes where ci=" + _ci;
                try
                {
                    rs = _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return (2);// ERROR AL CONSULTAR CLIENTE

                }
                if (rs.RecordCount == 0)
                {
                    resultado = 3;//NO ENCONTRE
                }
                else
                {
                    _nombre = Convert.ToString(rs.Fields[0].Value);
                    sql = "select telefono from cliente_telefonos where cliente=" + _ci;
                    try
                    {
                        rs = _conexion.Execute(sql, out filasAfectadas);
                    }
                    catch
                    {
                        return (4);
                    }
                    _telefonos.Clear();
                    while (!rs.EOF)/*INDICADOR DE QUE TERMINO EL RECORRIDO */
                    {
                        _telefonos.Add(Convert.ToString(rs.Fields[0].Value));
                        rs.MoveNext();
                    }
                }//if Record Count
                rs = null;
                filasAfectadas = null;
            } //if conection State

            return resultado;


        }
        public byte Guardar(Boolean modificacion)
        {
            string sql; object filasAfectadas; byte resultado = 0;
            if (_conexion.State == 0) //CONEXION CERRADA
            {
                resultado = 1;
            }
            else
            {  //CONEXION ABIERTA
                if (modificacion)
                {
                    sql = "update clientes set nombre='" + _nombre + " 'where ci= " + _ci;
                }
                else //ALTA
                {
                    sql = "insert into clientes(ci,nombre) values(" + _ci + ",'" + _nombre + "');";
                }
                try
                {
                    _conexion.Execute(sql, out filasAfectadas); /*cualquier sentencia sql que no sea un select, la ejecutaremos de esta forma*/
                }
                catch
                {
                    return (2);
                }
                if (modificacion)
                {
                    sql = "delete from cliente_telefonos where cliente=" + _ci;

                    try
                    {
                        _conexion.Execute(sql, out filasAfectadas);
                    }
                    catch
                    {
                        return (3);
                    }
                }

                foreach (string tel in _telefonos)
                {
                    sql = "insert into cliente_telefonos(cliente,telefono) values(" + _ci + ",'" + tel + "')";

                    try
                    {
                        _conexion.Execute(sql, out filasAfectadas);
                    }
                    catch
                    {
                        return (4);
                    }
                }
                filasAfectadas = null;
            } //if
            return (resultado);
        }//GUARDAR
        public byte Eliminar()
        {
            byte resultado = 0; string sql; object filasAfectadas;

            if (_conexion.State == 0)
            {
                resultado = 1; //CONEXIÓN CERRADA
            }
            else
            {
                sql = "delete from cliente_telefonos where cliente=" + _ci;
                try
                {

                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return (2);//ERROR AL BORRAR TELEFONOS
                }
                sql = "delete from clientes where ci =" + _ci;
                try
                {

                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {

                    return (3); //ERROR AL BORRAR CLIENTES
                }
                filasAfectadas = null;
            }//if

            return (resultado);
        }//eliminar



    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIGEN
{
    public partial class Entrenador : Form
    {
        public Entrenador()
        {
            InitializeComponent();
        }

        private void Entrenador_Load(object sender, EventArgs e)
        {
            btnGuardar.FlatStyle = FlatStyle.Flat; // Establece el estilo plano
            btnGuardar.TextAlign = ContentAlignment.MiddleCenter; // Centra el texto
            btnGuardar.FlatAppearance.BorderSize = 2; // Elimina el borde
            btnGuardar.FlatAppearance.BorderColor = Color.Black;

            button2.FlatStyle = FlatStyle.Flat; // Establece el estilo plano
            button2.TextAlign = ContentAlignment.MiddleCenter; // Centra el texto
            button2.FlatAppearance.BorderSize = 2; // Elimina el borde
            button2.FlatAppearance.BorderColor = Color.Black;


            btnBuscar.FlatStyle = FlatStyle.Flat; // Establece el estilo plano
            btnBuscar.TextAlign = ContentAlignment.MiddleCenter; // Centra el texto
            btnBuscar.FlatAppearance.BorderSize = 2; // Elimina el borde
            btnBuscar.FlatAppearance.BorderColor = Color.Black;


        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {


        }
        private void ConfigurarComboBoxEstado()
        {
            // Limpia los elementos actuales del ComboBox
            comboBox1.Items.Clear();

            // Verifica el contenido del textBox1
            switch (textBox1.Text)
            {
                case "Fisioterapia":
                    string[] fisioterapiaEstados = new string[] { "Inicio", "Sin evolución", "En evolución", "Satisfactorio" };
                    comboBox1.Items.AddRange(fisioterapiaEstados);
                    break;

                case "Deportista":
                    string[] deportistaEstados = new string[] { "Principiante", "Bajo", "Medio", "Alto", "Para Seleccionar" };
                    comboBox1.Items.AddRange(deportistaEstados);
                    break;

                default:
                    MessageBox.Show("Seleccione tipo de Cliente entre: 'Fisioterapia' o 'Deportista'");
                    break;
            }

            // Establece el índice seleccionado a -1
            comboBox1.SelectedIndex = -1;



        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e) //MOSTRAR ESTADO
        {
            ConfigurarComboBoxEstado();

            // Verifica el contenido del textBox1
            switch (textBox1.Text)
            {
                case "Fisioterapia":
                    // Establece el texto del ComboBox a "Fisioterapia"
                    comboBox1.Text = "Fisioterapia";
                    break;

                case "Deportista":
                    // Establece el texto del ComboBox a "Deportista"
                    comboBox1.Text = "Deportista";
                    break;

                default:
                    // Si no es ninguno de los anteriores, limpia el ComboBox
                    comboBox1.Text = string.Empty; // Limpia el texto del ComboBox
                    textBox1.Clear();
                    break;
            }

        }

        private void gbDatos_Enter(object sender, EventArgs e)
        {

        }

        private void gbBuscar_Enter(object sender, EventArgs e)
        {

        }
    }
}




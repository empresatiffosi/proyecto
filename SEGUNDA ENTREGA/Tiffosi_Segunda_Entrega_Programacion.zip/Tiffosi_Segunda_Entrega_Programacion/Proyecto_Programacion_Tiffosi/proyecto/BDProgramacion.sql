CREATE DATABASE mibase;
use mibase;
create table roles(
id tinyInt not null
, nombre varchar(50) not null
, primary key (id)
);
create table usuario_rol(
usuario varchar (50) not null
, rol tinyInt not null
, primary key(usuario)
, foreign key (rol) references roles (id)
);
create table clientes(
ci int not null,
nombre varchar (50) not null,
primary key(ci)
);
create table cliente_telefonos(
cliente int not null,
telefono varchar (12) not null,
primary key (cliente, telefono),
foreign key (cliente) references clientes (ci)
);

create user miusuario identified by "contrasena";
create user haikyuu identified by "shoyo";

grant select on usuario_rol to miusuario;
grant select on roles to miusuario;

grant select, update, delete, insert on clientes to miusuario;
grant select, update, delete, insert on cliente_telefonos to miusuario;


grant select on usuario_rol to haikyuu;
grant select on roles to haikyuu;

INSERT INTO roles (id, nombre)
VALUES (1, 'Compras')
,      (2, 'Ventas');
INSERT INTO usuario_rol(usuario,rol)
VALUES  ('miusuario', 2)
,        ('haikyuu', 1);
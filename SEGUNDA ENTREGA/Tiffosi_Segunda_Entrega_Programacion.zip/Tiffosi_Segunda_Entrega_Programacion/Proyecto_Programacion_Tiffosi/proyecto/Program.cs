﻿using SIGEN;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIGEN
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        public static Principal frmPrincipal;
        public static Login frmLogin;
        public static Clientes frmClientes;
        public static Entrenador frmEntrenador;
        public static Usuarios frmUsuarios;
        public static Rutina frmRutina;
        public static GestionUsuarios frmGestionUsuarios;
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(frmPrincipal = new Principal());

        }
        public static void Doypermisos(string usuario)
        {
            string sql;// cada vez que tengamos que hacer un select uvamos a tener que hacer esto
            object filasafectadas;
            ADODB.Recordset rs; // objeto de la clase rs
            byte rol = 0;
       
            if (cn.State != 0) //conexion abierta del login
            {
               
                sql = "select rol from usuario_rol where usuario='" + usuario + "'";
                try
                {
                    rs = cn.Execute(sql, out filasafectadas); // ejecucion

                }
                catch



                {
                    MessageBox.Show("error al obtener rol del usuario"); // prevee un error en la base de datos o conexion de red (IMPORNATE PARA EL PROYECTO)
                    return;
                }
 
                    if (rs.RecordCount == 0)
                    {

                        MessageBox.Show("el usuario no tiene rol asignado. Avisa al administrador");
                    }else{ //encontre uno, pues busque por PK(primary key)
                        rol = Convert.ToByte(rs.Fields[0].Value);





                    // Configurar la visualización del botón de administración según el rol
                    switch (rol)
                    {
                        case 1: //USUARIO CLIENTE
                            Program.frmPrincipal.menuEntrenadores.Visible = false;
                            Program.frmPrincipal.menuLogin.Visible = false;
                            Program.frmPrincipal.menuCerrarSesion.Visible = true;
                            Program.frmPrincipal.menuPerfil.Visible = true;
                            Program.frmPrincipal.menuAdministracion.Visible = false;
                            Program.frmPrincipal.menuRegistrarse.Visible = false;
                            Program.frmPrincipal.menuEntrenadores.Visible = false;
                                
                            break;
                        case 2: //USUARIO ADMINISTRATIVO
                            Program.frmPrincipal.menuEntrenadores.Visible = true;
                            Program.frmPrincipal.menuLogin.Visible = false;
                            Program.frmPrincipal.menuCerrarSesion.Visible = true;
                            Program.frmPrincipal.menuPerfil.Visible = true;
                            Program.frmPrincipal.menuAdministracion.Visible = false;
                            Program.frmPrincipal.menuRegistrarse.Visible = false;
                            Program.frmPrincipal.menuEntrenadores.Visible = false;



                            break;
                        case 3: //USUARIO AVANZADO
                            Program.frmPrincipal.menuEntrenadores.Visible = true;
                            Program.frmPrincipal.menuLogin.Visible = false;
                            Program.frmPrincipal.menuCerrarSesion.Visible = true;
                            Program.frmPrincipal.menuPerfil.Visible = true;
                            Program.frmPrincipal.menuAdministracion.Visible = false;
                            Program.frmPrincipal.menuRegistrarse.Visible = false;
                            Program.frmPrincipal.menuEntrenadores.Visible = false;

                            break;
                        case 4: //USUARIO ENTRENADOR    
                            Program.frmPrincipal.menuEntrenadores.Visible = true;
                            Program.frmPrincipal.menuEntrenador.Visible = true;
                            Program.frmPrincipal.menuClientes.Visible = false;
                            Program.frmPrincipal.menuLogin.Visible = false;
                            Program.frmPrincipal.menuCerrarSesion.Visible = true;
                            Program.frmPrincipal.menuPerfil.Visible = true;
                            Program.frmPrincipal.menuAdministracion.Visible = false;
                            Program.frmPrincipal.menuRegistrarse.Visible = false;

                            break;
                        case 5: //USUARIO SELECCIONADOR
                            Program.frmPrincipal.menuEntrenadores.Visible = true;
                            Program.frmPrincipal.menuLogin.Visible = false;
                            Program.frmPrincipal.menuCerrarSesion.Visible = true;
                            Program.frmPrincipal.menuPerfil.Visible = true;
                            Program.frmPrincipal.menuAdministracion.Visible = false;
                            Program.frmPrincipal.menuRegistrarse.Visible = false;
                            Program.frmPrincipal.menuEntrenadores.Visible = false;

                            break;
                        case 6: //USUARIO ADMINISTRADOR TI
                            Program.frmPrincipal.menuEntrenadores.Enabled = true;
                            Program.frmPrincipal.menuEntrenadores.Visible = true;
                            Program.frmPrincipal.menuClientes.Enabled = true;
                            Program.frmPrincipal.menuEntrenador.Enabled = true;
                            Program.frmPrincipal.menuLogin.Visible = false;
                            Program.frmPrincipal.menuCerrarSesion.Visible = true;
                            Program.frmPrincipal.menuPerfil.Visible = true;
                            Program.frmPrincipal.menuRegistrarse.Visible = false;
                            Program.frmPrincipal.menuAdministracion.Visible = true;

                            break;
                    }
                }


            }
        }

        
        public static ADODB.Connection cn = new ADODB.Connection(); /*Conector a una base de datos - 21/05/2024 - Público para que lo tengan todos los archivos del proyecto y Est+atico porque est+a en la clase estática program*/
    }
}

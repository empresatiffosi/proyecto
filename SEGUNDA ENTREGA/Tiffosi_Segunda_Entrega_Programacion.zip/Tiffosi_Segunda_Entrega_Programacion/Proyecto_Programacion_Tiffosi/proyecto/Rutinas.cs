﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Rutinas : Form
    {
        public Rutinas()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Entrenadores_Load(object sender, EventArgs e)
        {
            nombreEntrenador.ReadOnly = true;  // Establecer el TextBox como de solo lectura
            nombreEntrenador.BorderStyle = 0;  // Eliminar el borde para que se asemeje a un Label
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIGEN
{
    public partial class Usuarios : Form
    {
        protected ADODB.Connection _conexion;

        public Usuarios()
        {
            InitializeComponent();


            _conexion = new ADODB.Connection();


        }





        // Método SetContrasena
        public void SetContrasena(string contra)
        {
            txtContrasena2.Text = contra;
        }

        public void label6_Click(object sender, EventArgs e)
        {

        }

        public void txtContrasena2_TextChanged(object sender, EventArgs e)
        {

        }

        public void Usuarios_Load(object sender, EventArgs e)
        {
            label10.Font = new Font(label10.Font, label10.Font.Style | FontStyle.Underline);

            button2.FlatStyle = FlatStyle.Flat; // Establece el estilo plano
            button2.TextAlign = ContentAlignment.MiddleCenter; // Centra el texto
            button2.FlatAppearance.BorderSize = 2; // Elimina el borde
            button2.FlatAppearance.BorderColor = Color.Black;
            button2.BackColor = Color.White; // Establece el fondo blanco


            btnGuardar.FlatStyle = FlatStyle.Flat; // Establece el estilo plano
            btnGuardar.TextAlign = ContentAlignment.MiddleCenter; // Centra el texto
            btnGuardar.FlatAppearance.BorderSize = 2; // Elimina el borde
            btnGuardar.FlatAppearance.BorderColor = Color.Black;


            if (Program.cn.State != 0)
            {
                txtContrasena2.ReadOnly = true;  // Establecer el TextBox como de solo lectura
                txtContrasena2.BorderStyle = 0;  // Eliminar el borde para que se asemeje a un Label
            }

            comboBox1.Items.Add("Artigas");
            comboBox1.Items.Add("Canelones");
            comboBox1.Items.Add("Cerro Largo");
            comboBox1.Items.Add("Colonia");
            comboBox1.Items.Add("Durazno");
            comboBox1.Items.Add("Flores");
            comboBox1.Items.Add("Florida");
            comboBox1.Items.Add("Lavalleja");
            comboBox1.Items.Add("Maldonado");
            comboBox1.Items.Add("Montevideo");
            comboBox1.Items.Add("Paysandú");
            comboBox1.Items.Add("Río Negro");
            comboBox1.Items.Add("Rivera");
            comboBox1.Items.Add("Rocha");
            comboBox1.Items.Add("Salto");
            comboBox1.Items.Add("San José");
            comboBox1.Items.Add("Soriano");
            comboBox1.Items.Add("Tacuarembó");
            comboBox1.Items.Add("Treinta y Tres");

            // Opcional: seleccionar el primer ítem por defecto
            if (comboBox1.Items.Count > 0)
            {
                comboBox1.SelectedIndex = 0;
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //UPDATE A BD
        }

        private void button1_Click_1(object sender, EventArgs e) //BOTON CONTRASEÑA
        {
            if (txtContrasena2.PasswordChar == '*')
            {
                // Si la contraseña está oculta, la mostramos
                txtContrasena2.PasswordChar = '\0'; // '\0' indica que no hay ningún carácter para ocultar
            }
            else
            {
                // Si la contraseña está visible, la ocultamos
                txtContrasena2.PasswordChar = '*';
            }
        }








        private void txtCI_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtContrasena2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            int ci = int.Parse(Program.frmUsuarios.txtCI.Text); // Asegúrate de tener un TextBox para CI
            string nombre = Program.frmUsuarios.txtNombre.Text; // Asegúrate de tener un TextBox para Nombre
            string apellido = Program.frmUsuarios.txtApellido.Text; // Asegúrate de tener un TextBox para Nombre
            string telefono = Program.frmUsuarios.txtTelefono.Text; // Asegúrate de tener un TextBox para Teléfono
            DateTime fechaNacimiento = Program.frmUsuarios.dateTimePicker1.Value; // Asegúrate de tener un DateTimePicker

            string departamento = Program.frmUsuarios.comboBox1.SelectedItem.ToString();



            string sql = $"INSERT INTO clientes(nombre, apellido, ci, Fecha_de_nacimiento, Departamento, Telefono) " +
                         $"VALUES('{nombre}','{apellido}','{ci}', '{fechaNacimiento.ToString("yyyy-MM-dd")}', '{departamento}','{telefono}');";

            try
            {
                object filasAfectadas;
                Program.cn.Execute(sql, out filasAfectadas);
                MessageBox.Show("Información guardada con éxito.");
                this.Close(); // Opcional: Ocultar el formulario actual
                Program.frmPrincipal.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }

        }

        private void txtTelefono_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }

    

    }


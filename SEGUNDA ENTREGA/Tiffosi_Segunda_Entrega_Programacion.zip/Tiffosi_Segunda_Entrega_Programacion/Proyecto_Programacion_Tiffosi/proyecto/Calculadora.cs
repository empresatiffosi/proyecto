﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Calculadora : Form
    {
        System.Drawing.Color colorInicial;
        public Calculadora()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNum2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        double NumeroDouble(string valor) //FUNCIÓN
        {
            double resultado;
            if (!double.TryParse(valor, out resultado))
            {
                resultado = 0;
            }
            return (resultado);
        }//NumeroDouble
        void Efectuo(string operacion) //PROCEDIMIENTO 
        {
            Boolean openOK = true; String textoMostrar;
            double num1, num2, resultado=0;
            num1 = NumeroDouble(txtNum1.Text);
            num2 = NumeroDouble(txtNum2.Text);
            txtNum1.Text = Convert.ToString(num1);
            txtNum2.Text = Convert.ToString(num2);
            switch (operacion)
            {
                case "+": resultado = num1 + num2; break;
                case "-": resultado = num1 - num2; break;
                case "*": resultado = num1 * num2; break;
                case "/":
                    if (num2 != 0)
                    {
                        resultado = num1 / num2;
                    }
                    else
                    {
                        openOK = false;
                    }
                    break;
            }
            if (openOK)
            {
                lblResultado.Text = Convert.ToString(resultado);
                textoMostrar = num1 + operacion + num2 + "=" + resultado;
                lstResultado.Items.Add(textoMostrar);
                cboResultado.Items/*ATRIBUTO*/.Add/*METODO*/(textoMostrar);
            }
            else
            {
                lblResultado.Text = "NO EXISTE";

            }
        }
        void ActualizoPantalla()
        {
            lstResultado.Visible = chkResultado.Checked;
            cboResultado.Visible = chkResultado.Checked;
            if (chkFondo.Checked) {
                this.BackColor = Color.Aqua;
                
                } else {
                this.BackColor = colorInicial;

            }
        }

        private void btnSuma_Click(object sender, EventArgs e)
        {
            //lblResultado.Text = "Hola Mundo";
            //lblResultado.Text = txtNum1.Text;
            //lblResultado.Text = txtNum1.Text + txtNum2.Text; //Junta los 2 Strings de txtNum1 y 2
            //num1 = Convert.ToDouble(txtNum1.Text); //da excepciòn con letras
            Efectuo("+");
        }
        private void btnResta_Click(object sender, EventArgs e)
        {
            Efectuo("-");

        }

        private void btnMultiplicacion_Click(object sender, EventArgs e)
        {
            Efectuo("*"); //METODO
        }

        private void btnDivision_Click(object sender, EventArgs e)
        {
            Efectuo("/");
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            lblResultado.Text = "";
            txtNum1.Text = "";
            txtNum2.Text = "";
         
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cboResultado_SelectedIndexChanged(object sender, EventArgs e)
        {

        }




       private void chkResultado_CheckedChanged(object sender, EventArgs e)
        {
            ActualizoPantalla();
        }
        private void chkFondo_CheckedChanged(object sender, EventArgs e)
        {
            ActualizoPantalla();

        }
    }
}
